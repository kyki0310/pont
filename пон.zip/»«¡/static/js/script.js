// script.js

document.addEventListener('DOMContentLoaded', () => {
    // --- Плавное появление элементов при скролле (fade-in) ---
    const fadeInElements = document.querySelectorAll('.fade-in-element');

    const observerOptions = {
        root: null, // Наблюдатель относительно viewport
        rootMargin: '0px',
        threshold: 0.1 // 10% элемента должен быть виден
    };

    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('is-visible');
                observer.unobserve(entry.target); // Прекратить наблюдение после появления
            }
        });
    }, observerOptions);

    fadeInElements.forEach(element => {
        observer.observe(element);
    });

    // --- Изменение шапки при прокрутке ---
    const header = document.querySelector('header');
    const heroSection = document.querySelector('.hero-section');
    // Высота шапки, учитывая, что она может меняться при адаптации
    const getHeaderHeight = () => header ? header.offsetHeight : 80; 

    const handleScroll = () => {
        const headerHeight = getHeaderHeight();
        // Если Hero-секция существует, проверяем ее видимость
        if (heroSection) {
            const heroRect = heroSection.getBoundingClientRect();
            // Шапка становится 'scrolled' после того, как Hero-секция полностью прокручена вверх
            if (heroRect.bottom <= headerHeight) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        } else {
            // Если Hero-секции нет (например, на страницах деталей), шапка всегда "scrolled"
            if (window.scrollY > 0) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        }
    };

    window.addEventListener('scroll', handleScroll);
    window.addEventListener('resize', handleScroll); // Пересчитываем при изменении размера окна
    handleScroll(); // Вызываем при загрузке страницы, чтобы установить начальное состояние


    // --- Активная ссылка в навигации ---
    const navLinks = document.querySelectorAll('nav a');
    const currentPathname = window.location.pathname; // Получаем путь, например, "/cars.html" или "/car-detail-model_t.html"

    navLinks.forEach(link => {
        let linkHref = link.getAttribute('href'); // Получаем href, например, "cars.html" или "index.html"

        // Корректируем linkHref для сравнения с currentPathname
        // Убеждаемся, что linkHref начинается со слеша, если это относительный путь
        if (!linkHref.startsWith('/') && !linkHref.startsWith('http')) {
             linkHref = '/' + linkHref;
        }

        // Проверяем, совпадает ли текущий путь с href ссылки
        // Например, для "index.html" или "/index.html"
        if (currentPathname === linkHref) {
            link.classList.add('active');
        } 
        // Если это детальная страница, например, /car-detail-model_t.html,
        // то мы хотим, чтобы была активна ссылка "Автомобили" (/cars.html)
        // Для этого сравниваем общие префиксы
        else if (linkHref === '/cars.html' && currentPathname.startsWith('/car-detail-')) {
            link.classList.add('active');
        }
        else if (linkHref === '/companies.html' && currentPathname.startsWith('/company-detail-')) {
            link.classList.add('active');
        }
        // Специальная обработка для главной страницы, если путь "/"
        else if (linkHref === '/index.html' && currentPathname === '/') {
            link.classList.add('active');
        }
    });

    // --- Обработка формы контактов (только для демонстрации, без отправки) ---
    const contactForm = document.querySelector('.contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', (event) => {
            event.preventDefault(); // Предотвращаем стандартную отправку формы
            const successMessage = document.createElement('div');
            successMessage.className = 'success-message fade-in-element is-visible';
            successMessage.textContent = 'Ваше сообщение успешно отправлено (виртуально)!';
            contactForm.parentNode.insertBefore(successMessage, contactForm); // Добавляем перед формой
            contactForm.reset(); // Очищаем форму
            setTimeout(() => {
                successMessage.remove(); // Удаляем сообщение через 5 секунд
            }, 5000);
        });
    }
});